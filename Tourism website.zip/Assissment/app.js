const express = require("express")
const path = require("path")
const mongoose = require("mongoose")
async function main() {
    await mongoose.connect('mongodb://127.0.0.1:27017/test');}
const parser = require("bodu-parser")
const port = 8000
const app = express()

// express content 
app.use('/public', express.static('public')) ;// for surving statics file
app.use(express.urlencoded());

// respond with "hello world" when a GET request is made to the homepage
app.get('/', (req, res) => {
  res.send('/index.html')
});


// Start server
app.listen(port, ()=>{
    console.log(`the application start successfully on port ${port}`);
});


